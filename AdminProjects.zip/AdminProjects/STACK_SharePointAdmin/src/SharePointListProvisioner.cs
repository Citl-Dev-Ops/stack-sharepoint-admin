
using Microsoft.SharePoint.Client;
using System;
using System.Security;

namespace SharePointAdmin
{
    class SharePointListProvisioner
    {
        static void Main(string[] args)
        {
            string siteUrl = "https://rtcedu.sharepoint.com/sites/ITAdmin";
            string listTitle = "CourseRequests";

            Console.Write("Enter your username: ");
            string username = Console.ReadLine();

            Console.Write("Enter your password: ");
            SecureString password = GetSecurePassword();

            using (ClientContext context = new ClientContext(siteUrl))
            {
                context.Credentials = new SharePointOnlineCredentials(username, password);

                ListCreationInformation creationInfo = new ListCreationInformation
                {
                    Title = listTitle,
                    TemplateType = (int)ListTemplateType.GenericList
                };

                List list = context.Web.Lists.Add(creationInfo);
                context.ExecuteQuery();

                Console.WriteLine("[OK] Created list: " + listTitle);
            }
        }

        private static SecureString GetSecurePassword()
        {
            SecureString secureStr = new SecureString();
            ConsoleKeyInfo key;
            do
            {
                key = Console.ReadKey(intercept: true);
                if (key.Key != ConsoleKey.Enter)
                {
                    secureStr.AppendChar(key.KeyChar);
                    Console.Write("*");
                }
            } while (key.Key != ConsoleKey.Enter);
            Console.WriteLine();
            secureStr.MakeReadOnly();
            return secureStr;
        }
    }
}
