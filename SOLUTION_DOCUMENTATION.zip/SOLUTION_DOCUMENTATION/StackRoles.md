# Stack Roles

Describe ownership and responsibilities for each stack.